import numpy as np
import matplotlib.pyplot as plt

x = np.array([1,2,3,4,5,6,7,8,9,10,11,12])
e = np.array([7215.3,6815.0,7971.9,8604.7,9641.7,9242.2,9037.0,11036.1,11536.8,14723.0,14179.3,14645.5])
i = np.array([33280.6,22813.1,19805.4,31070.8,36598.2,37639.5,40657.3,40816.4,41208.3,44828.0,44855.5,41875.9])



plt.plot(x,e,'r',label='export')
plt.plot(x,i,'g',label='import')

plt.plot(x,e,'ro-',x,i,'g+-')

plt.xticks([0,5,10,15,20,25,30,35,40,45])

plt.fill_between(x,e,i,where=e>=i,facecolor='#00FF7F',interpolate=True)

plt.fill_between(x,e,i,where=i>e,facecolor='#FAF0E6',interpolate=True)

plt.grid(True)


plt.title('Import/Export Chart of China 2020')
plt.ylabel('million USD')
plt.xlabel('month')
plt.legend()
plt.show()

#x = np.array(range(50))
#e = np.random.randint(2000,10000, size=50)
#i = np.random.randint(0,8000, size=50)

# e_china = [7215.3,6815.0,7971.9,8604.7,9641.7,9242.2,9037.0,11036.1,11536.8,14723.0,14179.3,14645.5]
# i_china = [33280.6,22813.1,19805.4,31070.8,36598.2,37639.5,40657.3,40816.4,41208.3,44828.0,44855.5,41875.9]

# e_singapore = [2452.9,2713.5,2561.1,2411.5,1978.4,2098.3,1864.4,2087.0,2185.4,2262.9,2201.3,2269.6]
# i_singapore = [2536.6,1954.1,2437.5,3537.0,3383.2,2376.5,3342.8,1986.1,2153.7,2272.0,1989.9,2870.1]
